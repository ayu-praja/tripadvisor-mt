import { StopPipe } from './stop.pipe';

describe('StopPipe', () => {
  it('create an instance', () => {
    const pipe = new StopPipe();
    expect(pipe).toBeTruthy();
  });
});
