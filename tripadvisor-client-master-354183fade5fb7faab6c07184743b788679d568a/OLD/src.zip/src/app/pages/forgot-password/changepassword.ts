export class Changepassword {

    email:string;
    password:string;
}
