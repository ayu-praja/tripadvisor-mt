import { Changepassword } from './changepassword';

describe('Changepassword', () => {
  it('should create an instance', () => {
    expect(new Changepassword()).toBeTruthy();
  });
});
