import { Component, OnInit } from "@angular/core";
import { AuthService } from "../auth/auth.service";
import { Changepassword } from "./changepassword";

@Component({
  selector: "app-forgot-password",
  templateUrl: "./forgot-password.component.html",
  styleUrls: ["./forgot-password.component.scss"]
})
export class ForgotPasswordComponent implements OnInit {
  emailOver = true;
  otpSent = false;
  enterOtp = false;
  email: any;
  storedEmail: any;
  OTP: any;
  otp: any;
  rightOtp: boolean;
  password1: string;
  password2: string;
  errorMessage: string;
  otpNotTrue = false;
  invalidMail = false;
  invalidOtp = false;
  otpOn = true;
  constructor(private service: AuthService) {}
  pwdUpdateMsg: any;
  ngOnInit() {}

  sendOtp() {
    this.emailOver = false;
    this.otpSent = true;
    console.log(this.email);
    this.storedEmail = this.email;
    this.service.sendOtp(this.email).subscribe(
      data => {
        console.log(data);
        this.OTP = data;
      },
      error => {
        this.emailOver = true;
        console.log(error.error.message);
        this.invalidMail = true;
        this.otpOn = false;
        this.errorMessage = error.error.message;
      }
    );
  }
  validateOtp() {
    this.otpSent = false;
    this.enterOtp = true;
    if (this.otp == this.OTP) {
      console.log(this.otp);
      console.log("here");

      this.rightOtp = true;
      this.otpSent = false;
      // this.otpNotTrue=false
    } else {
      console.log(this.otp);
      console.log(this.OTP);
      // this.otpNotTrue=true
      this.otpSent = true;
      this.rightOtp = false;
      console.log(this.rightOtp);
    }
  }
  updatePassword() {
    if (this.password1 == this.password2) {
      let changePassword = new Changepassword();
      changePassword.email = this.storedEmail;
      changePassword.password = this.password1;
      this.service.passwordUpdate(changePassword).subscribe(data => {
        this.pwdUpdateMsg = data;
        console.log(data);
      });
    }
  }
}
