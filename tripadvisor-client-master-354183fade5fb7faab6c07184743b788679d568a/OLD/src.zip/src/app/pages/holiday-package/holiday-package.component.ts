import { Component, OnInit, Inject } from "@angular/core";
import { HolidayPackageServiceService } from "../service/holiday-package-service.service";
import { NgxSpinnerService } from "ngx-spinner";
import * as moment from "moment";
import { Holiday } from "./Holiday";

@Component({
  selector: "app-holiday-package",
  templateUrl: "./holiday-package.component.html",
  styleUrls: ["./holiday-package.component.scss"]
})
export class HolidayPackageComponent implements OnInit {
  cities: Holiday[] = [];
  errorStatus = false;
  clearOnButtonClick = false;
  dateMistake = false;
  errorMessage: any;
  source: any;
  destination: any;
  sourcecheck = false;
  date: any;
  holiday: any;
  packages: any[] = [];
  difference: any;
  images: any[] = [];
  constructor(
    @Inject(HolidayPackageServiceService)
    private holidayService: HolidayPackageServiceService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {
    this.holidayService.getHolidayCities().subscribe(data => {
      for (let i = 0; i < data.holidaycities.length; i++) {
        var holiday = new Holiday();
        holiday.city = data.holidaycities[i].city_name;
        this.cities.push(holiday);
      }
      this.destination = this.cities[0];
    });
  }
  enableFilter() {
    if (this.source === this.destination.city) {
      this.sourcecheck = true;
    } else {
      this.sourcecheck = false;
    }

    this.clearOnButtonClick = true;
    this.spinner.show();
    var now = new Date();
    var now2 = new Date(this.date);
    console.log(now);
    var a = moment(now);
    var b = moment(now2);
    this.difference = b.diff(a, "days");
    console.log(this.difference);
    this.errorStatus = false;
    console.log(this.destination);

    if (this.difference >= 0) {
      this.dateMistake = false;
      this.holidayService.getPackage(this.destination.city).subscribe(
        data => {
          this.clearOnButtonClick = false;
          // this.dateMistake=true;
          this.spinner.hide();
          this.holiday = data;
          // this.childPackage.getPlace(this.holiday);
          this.packages = this.holiday.packages;
          console.log(this.packages);
          for (let i = 0; i < this.packages.length; i++) {
            this.images[i] = this.packages[i].package_image.split("|");
            this.packages[i]["imageurl"] = this.images[i];
          }
        },
        error => {
          this.clearOnButtonClick = false;
          this.errorStatus = true;
          // this.dateMistake=true;
          this.spinner.hide();
          this.errorMessage = error;
          console.log(error);
        }
      );
    } else {
      this.dateMistake = true;
    }
  }
}
