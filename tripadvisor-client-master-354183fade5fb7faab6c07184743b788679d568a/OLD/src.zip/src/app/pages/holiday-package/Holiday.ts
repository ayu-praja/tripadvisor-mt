export class Holiday
{
    city:string
}