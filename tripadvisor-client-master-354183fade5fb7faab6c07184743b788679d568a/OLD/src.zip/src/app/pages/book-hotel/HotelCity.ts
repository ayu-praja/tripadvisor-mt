export class HotelCity
{
    city:string
}